CREATE TABLE "HR"."RECOMMEND"
(	
	"RE_NO" NUMBER(38,0), 
	"TITLE" VARCHAR2(100), 
	"CONTENTS" VARCHAR2(100), 
	"WRITER" VARCHAR2(100) 

	) 
   
CREATE TABLE "HR"."RECOMMEND"
(	
	"RE_NO" NUMBER(38,0), 
	"TITLE" VARCHAR2(100), 
	"CONTENTS" VARCHAR2(100), 
	"WRITER" VARCHAR2(100) 

	) 
	
	ALTER TABLE HR.RECOMMEND DROP COLUMN VIEWCOUNT; -- 한 단락만 삭제한다.

	
	DROP TABLE RECOMMEND -- 한 테이블을 통째로 삭제한다.
	
	ALTER TABLE HR.RECOMMEND ADD VIEWCOUNT NUMBER(38,0) NULL;

	
	
  CREATE TABLE RECOMMEND2(
  	RE_NO NUMBER(38,0),
  	TITLE VARCHAR2(100),
  	CONTENT VARCHAR2(100),
  	WRITER VARCHAR2(100)
  )
  
  CREATE TABLE "HR"."BOARD3" 
   (	"BOARDNO" NUMBER(38,0), 
	"TITLE" VARCHAR2(100), 
	"CONTENTS" VARCHAR2(100), 
	"WRITER" VARCHAR2(100), 
	"WRITEDATE" DATE, 
	"RECOMMEND" NUMBER(38,0), 
	"VIEWCOUNT" NUMBER(38,0)
   )
   
 	ALTER TABLE HR.BOARD3 ADD  test5 varchar2(100)
 	
 	ALTER TABLE HR.BOARD3 DROP COLUMN  TEST5
 	
 	ALTER TABLE HR.BOARD3 DROP COLUMN  TEST2
	
 	ALTER TABLE HR.BOARD3 DROP COLUMN TEST1;

 	ALTER TABLE HR.BOARD3 MODIFY WRITER VARCHAR2(200)
 	
 	DROP TABLE MEMBER3 
 	
 	--DCL : DB 관리 /제어해주는 문법 (계정생성, 계정권한부여, 백업, 복구)
 	
 	CREATE USER apple IDENTIFIED BY  a1234
 	
 	GRANT CONNECT, RESOURCE, DBA TO apple
 	
 	REVOKE resource FROM APPLE
 	
 	DROP USER APPLE CASCADE

 	DROP USER apple CASCADE
 	
 	CREATE TABLE bbs (
 	NO varchar2(100),
 	title varchar2(100),
 	CONTENT varchar2(100),
 	WRITER varchar2(100)
 	)
 	
 	CREATE TABLE product(
 	id varchar2(100) PRIMARY key,
 	name varchar2(100),
 	content varchar2(100),
	price number10(38,0)
 	)
 	
 	INSERT into MEMBER VALUES ('100','100','park','011')

 	INSERT into MEMBER VALUES ('200','200','park','011')
 	
 	INSERT into MEMBER VALUES ('300','300','park','011')
 	
 	SELECT * FROM MEMBER
 
 	SELECT * FROM MEMBER WHERE id = '100' -- id가 100인 id 칼럼
 	
 	SELECT id, name FROM MEMBER WHERE id = '100' -- id가 100인 id, name 컬럼

 	SELECT name, id FROM MEMBER WHERE id = '100' -- id가 100인 name, id 컬럼

 	SELECT id AS 아이디, name FROM MEMBER WHERE id = '100' -- id가 100인데 열에 아이디로 나오게 바꾸고 name 나오게 하는 것 
 	
 	SELECT * FROM MEMBER
 	
 	
 	UPDATE MEMBER SET name = 'kim' where id = '100'

 	UPDATE MEMBER SET name = 'yang' where id = '200'

 	UPDATE MEMBER SET name = 'lee' where id = '300'

 	UPDATE MEMBER SET pw = '8888', tel= '9999' where id = 'ice'
 	
 	SELECT * FROM MEMBER
 	
 	DELETE FROM MEMBER WHERE id = '100'

 	DELETE FROM MEMBER WHERE tel = '011'
 	
 	SELECT * FROM MEMBER WHERE id = '200' AND tel = '011'
 	
 	SELECT * FROM MEMBER WHERE id = '200' AND tel = '011'
 	
 	
 	--id name content price	company	img

 	CREATE TABLE product(
 	id varchar2(200),
 	name varchar2(200),
 	content varchar2(200),
 	price varchar2(200),
 	company varchar2(200),
 	img varchar2(200)
 	)
 	
 




 	
 	--company로 오름차순 정렬하여 제품의 이름, 내용, 가격 검색
 	SELECT * FROM PRODUCT
 	
 	--price로 내림차순 정렬하여 전체컬럼 검색
 	SELECT * FROM PRODUCT ORDER BY id DESC
 	
 	--company로 오름차순 정렬하여 제품의 이름, 내용, 가격 검색
 	SELECT * FROM PRODUCT ORDER BY company
 	
 	SELECT NAME, CONTENT, PRICE  FROM product ORDER BY COMPANY 
 	
 	--id가 100인 제품의 이름과 가격 검색
 	SELECT name, price FROM PRODUCT WHERE id = '100'
 	
 	--price가 5000인 제품명과 회사명
 	SELECT name, company FROM PRODUCT where price = '5000'
 	
 	--id가 100이고 가격이 1000인 제품명과 이미지 검색
 	SELECT name,img FROM product where id = '100' AND price = '1000'
 	
 	--회사명이 c100인 회사명과 제품명
 	SELECT company, name FROM product where company = 'c100'
 	

	--회사명이 c100, c200인 제품명과 가격
 	SELECT name, price FROM product WHERE company = 'c100' OR company = 'c200'
 	

	--price가 5000원인 제품의 content를 품절로 수정
 	update product SET content = '품절' WHERE price ='5000'
 	
 	--id가 100, 102번 제품의 img를 o.png로, price를 10000으로 수정
 	UPDATE product SET img = 'o.png', price ='10000' WHERE id = '100' OR id = '200' 
 
 	
	--id가 101번 제품의 company를 apple, name은 appleshoes로 수정
 	UPDATE product SET COMPANY = 'apple', name = 'appleshoes' WHERE id = '101'
 	
 	--name이 shoes1이거나 id가 107인 제품 삭제
 	DELETE FROM PRODUCT WHERE name = 'shoes1' OR id = '107'
 	
 	--회사명이 c100인 경우 모든 정보 삭제
 	DELETE FROM product WHERE company = 'c100'
 
	--테이블의 모든 정보 삭제
	DELETE FROM product
	
	--테이블 삭제
	DROP TABLE product